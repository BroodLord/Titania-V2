How to use :
------------
To show the skybox with the viewer, just copy :

Skybox.exe
logo.bmp

Under the skybox directory, that all :)
