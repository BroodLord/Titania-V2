
Contact:	Martin Reznicek
e-mail:		remark3d@remark3d.cz
webs:		http://www.remark3d.cz
		http://remark3d.host.sk
		
To see available Materials, Stock Photography or Texture Maps type in "remark3d" for your next asset search in Turbo Squid.

Other matlibs and hires textures (all are free) you can download from my website! ;-) 